hostname
whoami
echo "Hello, World!"
pwd
mkdir dirA dirB dirC
ls
touch dirA/fileA dirB/fileB dirC/fileC
tree
rm -r dirA dirB dirC
